from django.urls import path,include
from App1 import views
from django.conf.urls.static import static 
from django.conf import settings

urlpatterns = [
    
    path('',views.home1),
    path('home',views.home),
    path('create',views.userReg),
    path('adminhome',views.adminhome),
    path('userhome',views.userhome),
    path('userviewTable',views.userviewTable),
    path('userviewDishes',views.userviewDishes),
    path('about',views.about),
    path('contact',views.contact),
    path('loginp',views.loginp),
    path('adminDishes',views.adminDishes),
    path('addDishes',views.addDishes),
    # path('editDishes',views.editDishes),
    path('adminTable',views.adminTable),
    path('arrangetables',views.arrangetables),
    path('userupdate',views.viewUsers),
    path('adminlogOut',views.adminlogOut),
    path('userlogOut',views.userlogOut),
    path('update',views.update),
    path('delete1',views.delete),
    path('reserveTable',views.reserveTable),
    path('bookTables',views.bookTable),
    path('orderreg/<id>/<price>/<str:t>',views.orderreg),
    path('trackBooking',views.vieworderUser),
    path('viewbooking',views.vieworderAdmin),
    path('order_approval/<id>',views.order_approval),
    path('order_rejection/<id>',views.order_rejection),
    path('paymentReg/<id>/<p>',views.paymentRegistration),
    path('viewpayment',views.viewPay),
    path('userviewdishes',views.userviewdishes),
    path('orderFood',views.userviewDishes2),
    path('orderReg/<id>/<price>/<str:q>',views.foodorderReg),
    path('trackFoodorder',views.trackFoodorderuser),
    path('viewbooking2',views.trackFoodorderAdmin),
    path('foodorder_approval/<id>',views.foodorder_approval),
    path('foodorder_rejection/<id>',views.foodorder_rejection),
    path('foodpaymentReg/<id>/<p>',views.foodpaymentRegistration),
    path('viewpayment2',views.foodviewPay)
    
]
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
